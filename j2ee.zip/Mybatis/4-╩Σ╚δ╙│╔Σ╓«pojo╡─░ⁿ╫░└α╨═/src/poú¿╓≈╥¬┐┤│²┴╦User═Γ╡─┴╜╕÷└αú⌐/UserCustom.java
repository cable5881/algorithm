package cn.itcast.mybatis.po;

/**
 * 
 * <p>Title: UserCustom</p>
 * <p>Description: 用户的扩展类</p>
 * <p>Company: www.itcast.com</p> 
 * @author	传智.燕青
 * @date	2015-4-22下午4:26:31
 * @version 1.0
 */
public class UserCustom extends User{
	
	//可以扩展用户的信息

}
