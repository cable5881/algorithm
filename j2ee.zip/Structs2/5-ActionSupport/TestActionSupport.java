package com.atguigu.struts2.action;

import com.opensymphony.xwork2.ActionSupport;

public class TestActionSupport extends ActionSupport {

	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		return SUCCESS;
	}
	
}
