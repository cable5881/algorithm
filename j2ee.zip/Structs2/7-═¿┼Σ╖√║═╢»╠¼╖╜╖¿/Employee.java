package com.atguigu.struts.valuestack.app;

import java.util.List;
import java.util.Map;

import org.apache.struts2.interceptor.RequestAware;

public class Employee implements RequestAware{
	
	private Map<String, Object> requestMap = null;
	
	private Dao dao = new Dao();
	
	private String name;
	private String password;
	
	private String gender;
	private String dept;
	
	private List<String> roles;
	private String desc;
	
	public String save(){
		System.out.println("save: " + this);
		return "save";
	}
	
	public String input(){
		requestMap.put("depts", dao.getDepartments());
		requestMap.put("roles", dao.getRoles());
		return "input";
	}

	@Override
	public void setRequest(Map<String, Object> request) {
		this.requestMap = request;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", password=" + password
				+ ", gender=" + gender + ", dept=" + dept + ", roles=" + roles
				+ ", desc=" + desc + "]";
	}
	

	set and get.....
}
