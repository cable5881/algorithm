package com.atguigu.struts2.action;

public class TestAction {

	public String execute(){
		System.out.println("TestAction's execute....");
		return "success";
	}
	
}
