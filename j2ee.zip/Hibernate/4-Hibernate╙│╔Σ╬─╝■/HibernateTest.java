public class HibernateTest {

	@Test
	public void testComponent(){
		Worker worker = new Worker();
		Pay pay = new Pay();
		
		pay.setMonthlyPay(1000);
		pay.setYearPay(80000); 
		pay.setVocationWithPay(5);
		
		worker.setName("ABCD");
		worker.setPay(pay);
		
		session.save(worker);
	}
	
	@Test
	public void testBlob() throws Exception{
//		News news = new News();
//		news.setAuthor("cc");
//		news.setContent("CONTENT");
//		news.setDate(new Date());
//		news.setDesc("DESC");
//		news.setTitle("CC");
//		
//		InputStream stream = new FileInputStream("Hydrangeas.jpg");
		//采用Hibernate工具类获取图片路径
//		Blob image = Hibernate.getLobCreator(session)
//				              .createBlob(stream, stream.available());
//		news.setImage(image);
//		
//		session.save(news);
		
		News news = (News) session.get(News.class, 1);
		Blob image = news.getImage();
		
		InputStream in = image.getBinaryStream();
		System.out.println(in.available()); 
	}
	
	@Test
	public void testPropertyUpdate(){
		News news = (News) session.get(News.class, 1);
		news.setTitle("aaaa"); 
		
		System.out.println(news.getDesc());
		System.out.println(news.getDate().getClass()); 
	}
	
	@Test
	public void testIdGenerator() throws InterruptedException{
		News news = new News("AA", "aa", new java.sql.Date(new Date().getTime()));
		session.save(news); 
		
//		Thread.sleep(5000); 
	}
	
	@Test
	public void testDynamicUpdate(){
		News news = (News) session.get(News.class, 1);
		news.setAuthor("AABCD");
		
	}
	
}
