package com.lqb.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.junit.Test;

import com.lqb.testHibernate.Person;

public class TestHelloWorld {

	@Test
	public void test() {

		final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
				.configure() // Ĭ��Ϊ hibernate.cfg.xml
				.build();
		
		SessionFactory sessionFactory = null;
		
		try {
			sessionFactory = new MetadataSources( registry ).buildMetadata().buildSessionFactory();
			// 2. ����һ�� Session ����
			Session session = sessionFactory.openSession();
			// 3. ��������
			session.beginTransaction();
			// 4. ִ�б������
			session.save(new Person("lqb22", 22, true));
			// 5. �ύ����
			session.getTransaction().commit();
			// 6. �ر� Session
			session.close();
			// 7. �ر� SessionFactory ����
			sessionFactory.close();
		}
		catch (Exception e) {
			// The registry would be destroyed by the SessionFactory, but we had trouble building the SessionFactory
			// so destroy it manually.
			StandardServiceRegistryBuilder.destroy( registry );
		}
		
	}

}
