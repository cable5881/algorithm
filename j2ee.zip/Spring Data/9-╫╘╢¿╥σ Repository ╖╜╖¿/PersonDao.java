package com.atguigu.springdata;

public interface PersonDao {
	
	void test();
	
}
