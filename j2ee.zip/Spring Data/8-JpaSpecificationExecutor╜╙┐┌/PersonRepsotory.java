public interface PersonRepsotory extends JpaSpecificationExecutor<Person>{

}
 