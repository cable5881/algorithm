package com.lqb.springdata.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.lqb.springdata.domain.Person;

//��һ��finaAll����
public interface PersonCRUDRepository extends PagingAndSortingRepository<Person, Integer>{

	
}
