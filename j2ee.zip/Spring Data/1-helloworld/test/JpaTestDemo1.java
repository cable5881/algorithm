package com.lqb.springdata.test;

import java.sql.SQLException;
import javax.sql.DataSource;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lqb.springdata.domain.Person;
import com.lqb.springdata.repository.PersonRepository;

public class JpaTestDemo1 {

	private ClassPathXmlApplicationContext cxt = null;
	private PersonRepository personRepository = null;
	
	@Before
	public void before(){
		cxt = new ClassPathXmlApplicationContext("application-context.xml");
		personRepository = cxt.getBean(PersonRepository.class);
	}
	
	@After
	public void after(){
		cxt.close();
	}
	
	@Test
	public void testDataSource() throws SQLException {
		DataSource dataSource = cxt.getBean(DataSource.class);
		System.out.println(dataSource.getConnection().toString());
	}
	
	@Test
	public void testSpringDataHelloWorld(){
		Person person = personRepository.getByLastName("bryant");
		System.out.println(person);
	}

}
