public class SpringDataTest {

	private ApplicationContext ctx = null;
	private PersonRepository personRepository = null;
	private PersonService personService;
	
	{
		ctx = new ClassPathXmlApplicationContext("applicationContext.xml");
		personRepository = ctx.getBean(PersonRepository.class);
		personService = ctx.getBean(PersonService.class);
	}
	
	//����ԭ��SQL
	@Test
	public void testNativeQuery(){
		long count = personRepository.getTotalCount();
		System.out.println(count);
	}
	
	@Test
	public void testQueryAnnotationLikeParam(){
//     ��Ҫ������˳�����ռλ�����ڲ�����
//		List<Person> persons = personRepository.testQueryAnnotationLikeParam("%A%", "%bb%");
//		System.out.println(persons.size());

//     ��Ҫ������˳��ص�ռλ���ڽӿڵ�SQLע����
//		List<Person> persons = personRepository.testQueryAnnotationLikeParam("A", "bb");
//		System.out.println(persons.size());
		
		//����Ҫ��˳����ռλ���ڽӿڵ�SQLע����
		List<Person> persons = personRepository.testQueryAnnotationLikeParam2("bb", "A");
		System.out.println(persons.size());
	}
	
	@Test
	public void testQueryAnnotationParams2(){
		List<Person> persons = personRepository.testQueryAnnotationParams2("aa@atguigu.com", "AA");
		System.out.println(persons);
	}
	
	@Test
	public void testQueryAnnotationParams1(){
		List<Person> persons = personRepository.testQueryAnnotationParams1("AA", "aa@atguigu.com");
		System.out.println(persons);
	}
	
	@Test
	public void testQueryAnnotation(){
		Person person = personRepository.getMaxIdPerson();
		System.out.println(person);
	}
	
}
