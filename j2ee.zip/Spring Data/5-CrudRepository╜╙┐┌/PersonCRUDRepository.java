package com.lqb.springdata.repository;

import org.springframework.data.repository.CrudRepository;
import com.lqb.springdata.domain.Person;

//CrudRepository<Person, Integer>
//methods:
//save/saveAll/delete/exists/findAll/count/findOne/
public interface PersonCRUDRepository extends CrudRepository<Person, Integer> {

	
}
