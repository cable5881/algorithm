package com.lqb.service;

import com.lqb.po.User;

public interface UserService {
	public User findUserById(int id);
}
