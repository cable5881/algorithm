package com.lqb.service;

import java.util.List;
import com.lqb.po.ItemsCustom;
import com.lqb.po.ItemsQueryVo;

public interface ItemsService {
	public List<ItemsCustom> findItemsList()throws Exception;
}
