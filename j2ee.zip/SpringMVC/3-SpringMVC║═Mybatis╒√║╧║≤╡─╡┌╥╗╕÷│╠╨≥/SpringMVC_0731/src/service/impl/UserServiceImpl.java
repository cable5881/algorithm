package com.lqb.service.impl;

import org.springframework.beans.factory.annotation.Autowired;

import com.lqb.mapper.UserMapper;
import com.lqb.po.User;
import com.lqb.service.UserService;

public class UserServiceImpl implements UserService {

	@Autowired
	private UserMapper usermapper;
	
	@Override
	public User findUserById(int id) {
		// TODO Auto-generated method stub
		return usermapper.selectByPrimaryKey(id);
	}

}
