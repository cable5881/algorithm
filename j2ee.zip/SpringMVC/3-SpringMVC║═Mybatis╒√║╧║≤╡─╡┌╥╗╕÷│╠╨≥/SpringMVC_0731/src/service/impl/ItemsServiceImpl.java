package com.lqb.service.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import com.lqb.mapper.ItemsMapperCustom;
import com.lqb.po.ItemsCustom;
import com.lqb.service.ItemsService;

public class ItemsServiceImpl implements ItemsService {
	
	@Autowired
	private ItemsMapperCustom ItemsMapperCustom;

	@Override
	public List<ItemsCustom> findItemsList() throws Exception {
		return ItemsMapperCustom.findItemsList();
	}
	


}
