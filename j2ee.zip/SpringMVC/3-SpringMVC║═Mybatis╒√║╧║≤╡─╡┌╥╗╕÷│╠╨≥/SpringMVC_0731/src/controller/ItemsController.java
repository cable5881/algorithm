package com.lqb.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lqb.po.Items;
import com.lqb.po.ItemsCustom;
import com.lqb.po.ItemsQueryVo;
import com.lqb.service.ItemsService;

@Controller
public class ItemsController {

	@Autowired
	private ItemsService itemsService;
	
	@RequestMapping("/queryItems")
	public ModelAndView queryItems()throws Exception{
		/*System.out.println(request.getParameter("id"));*/
		ItemsCustom custom = new ItemsCustom();
		custom.setName("台式");
		ItemsQueryVo vo = new ItemsQueryVo();
		vo.setItemsCustom(custom);
//		 调用service查找 数据库，查询商品列表
		List<ItemsCustom> itemsList = itemsService.findItemsList();
		
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("itemsList", itemsList);
		modelAndView.setViewName("/itemsList.jsp");

		return modelAndView;

	}

}
