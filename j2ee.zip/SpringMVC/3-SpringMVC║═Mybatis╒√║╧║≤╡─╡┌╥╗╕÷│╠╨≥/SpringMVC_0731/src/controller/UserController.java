package com.lqb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.lqb.po.User;
import com.lqb.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@RequestMapping("/queryUser")
	public ModelAndView findUserById() throws Exception{
		System.out.println("ddd");
		User user = userService.findUserById(1);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("User", user);
		modelAndView.setViewName("/user.jsp");
		return modelAndView;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}
	
	
}
