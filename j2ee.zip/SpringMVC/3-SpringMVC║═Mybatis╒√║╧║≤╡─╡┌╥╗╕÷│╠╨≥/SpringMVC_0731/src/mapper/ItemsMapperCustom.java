package com.lqb.mapper;

import java.util.List;
import com.lqb.po.ItemsCustom;

public interface ItemsMapperCustom {
    //商品查询列表
	public List<ItemsCustom> findItemsList()throws Exception;
}