package com.atguigu.spring.hibernate.service;

public interface BookShopService {
	
	public void purchase(String username, String isbn);
	
}
