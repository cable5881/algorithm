package com.atguigu.spring.struts2.services;

public class PersonService {
	
	public void save(){
		System.out.println("PersonService's save....");
	}
	
}
