package com.lqb.test2;

import org.springframework.stereotype.Service;

@Service
public class UserService extends BaseService<User> {

}
