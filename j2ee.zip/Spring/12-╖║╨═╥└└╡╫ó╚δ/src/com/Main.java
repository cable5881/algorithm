package com.lqb.test2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beans2.xml");
		UserService userService = (UserService) context.getBean("userService");
		userService.add();
		//�������UserRepository
		//add...
		//com.lqb.test2.UserRepository@b3d7190
	}

}
