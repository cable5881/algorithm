package com.lqb.test2;

public class BaseRepository<T> {

}
