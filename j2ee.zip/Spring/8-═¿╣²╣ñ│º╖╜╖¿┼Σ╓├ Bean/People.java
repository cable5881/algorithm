package com.lqb.test;

import java.util.Map;

public class People {
	private String name;
	private int age;
	private Map<String, String> habbits;
	public Map<String, String> getHabbits() {
		return habbits;
	}
	public void setHabbits(Map<String, String> habbits) {
		this.habbits = habbits;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "People [name=" + name + ", age=" + age + ", habbits=" + habbits + "]";
	}
	public People(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	
	
}
