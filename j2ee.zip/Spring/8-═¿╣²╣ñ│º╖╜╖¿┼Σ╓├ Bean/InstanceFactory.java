package com.lqb.test;

import java.util.HashMap;
import java.util.Map;

public class InstanceFactory {

private Map<String,People> persons = new HashMap<>();
	
	public InstanceFactory(){
		persons.put("p1", new People("lqb",22));
		persons.put("p2", new People("james",32));
	}
	
	public People getPersons(String key){
		return persons.get(key);
	}
	
}
