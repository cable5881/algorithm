package com.lqb.test;

import java.util.HashMap;
import java.util.Map;

public class StaticFactory {
	
	private static Map<String,People> persons = new HashMap<>();
	
	static{
		persons.put("p1", new People("lqb",22));
		persons.put("p2", new People("james",32));
	}
	
	public static People getPersons(String key){
		return persons.get(key);
	}
}
